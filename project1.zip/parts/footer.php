</div>
<script src="./js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="./js/conffit.js?=<?php echo time(); ?>" type="module"></script>
<script src="./js/loader.js?=<?php echo time(); ?>"></script>
<script src="./js/script.js?=<?php echo time(); ?>"></script>

</body>
</html>
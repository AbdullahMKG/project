<?php 


$conn = mysqli_connect('localhost', 'u672174732_win', '2211@AMGamg2211', 'u672174732_win');
if(!$conn){
     echo 'fail' .mysqli_connect_error();
}